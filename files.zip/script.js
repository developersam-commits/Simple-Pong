// Simple Pong game
// Left paddle controlled by mouse and ArrowUp/ArrowDown keys.
// Right paddle is a basic AI. Scoreboard and collisions included.

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

const leftScoreEl = document.getElementById('left-score');
const rightScoreEl = document.getElementById('right-score');
const statusEl = document.getElementById('status');

const W = canvas.width;
const H = canvas.height;

// Game settings
const PADDLE_WIDTH = 12;
const PADDLE_HEIGHT = 100;
const PADDLE_SPEED = 6; // keyboard speed
const AI_MAX_SPEED = 4.0;
const BALL_SIZE = 12;
const BALL_SPEED_START = 4;
const BALL_SPEED_INCREMENT = 0.25;
const WIN_SCORE = 10;

let leftScore = 0;
let rightScore = 0;

let isPaused = false;
let isRunning = true;

// Left paddle (player)
const leftPaddle = {
  x: 20,
  y: (H - PADDLE_HEIGHT) / 2,
  width: PADDLE_WIDTH,
  height: PADDLE_HEIGHT,
  dy: 0
};

// Right paddle (computer)
const rightPaddle = {
  x: W - 20 - PADDLE_WIDTH,
  y: (H - PADDLE_HEIGHT) / 2,
  width: PADDLE_WIDTH,
  height: PADDLE_HEIGHT
};

// Ball
const ball = {
  x: W / 2,
  y: H / 2,
  size: BALL_SIZE,
  speed: BALL_SPEED_START,
  dx: 0,
  dy: 0
};

function resetBall(direction = 1) {
  ball.x = W / 2;
  ball.y = H / 2;
  ball.speed = BALL_SPEED_START;
  // direction: -1 means left, 1 means right
  const angle = (Math.random() * Math.PI / 4) - (Math.PI / 8); // random small angle
  ball.dx = Math.cos(angle) * ball.speed * direction;
  ball.dy = Math.sin(angle) * ball.speed;
}

function startRound(serveTo = 1) {
  resetBall(serveTo);
  statusEl.textContent = '';
}

function drawNet() {
  ctx.strokeStyle = '#333';
  ctx.lineWidth = 2;
  const step = 16;
  for (let y = 0; y < H; y += step) {
    ctx.beginPath();
    ctx.moveTo(W / 2, y + 6);
    ctx.lineTo(W / 2, y + 10);
    ctx.stroke();
  }
}

function draw() {
  // clear
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, W, H);

  // net
  drawNet();

  // paddles
  ctx.fillStyle = '#fff';
  ctx.fillRect(leftPaddle.x, leftPaddle.y, leftPaddle.width, leftPaddle.height);
  ctx.fillRect(rightPaddle.x, rightPaddle.y, rightPaddle.width, rightPaddle.height);

  // ball
  ctx.fillStyle = '#fff';
  ctx.fillRect(ball.x - ball.size/2, ball.y - ball.size/2, ball.size, ball.size);
}

function clamp(v, a, b) {
  return Math.max(a, Math.min(b, v));
}

function update() {
  if (isPaused || !isRunning) return;

  // Move left paddle by keyboard
  leftPaddle.y += leftPaddle.dy;
  leftPaddle.y = clamp(leftPaddle.y, 0, H - leftPaddle.height);

  // Move right paddle (AI) toward ball
  const targetY = ball.y - rightPaddle.height / 2;
  const diff = targetY - rightPaddle.y;
  // AI moves proportional to difference but limited by max speed
  rightPaddle.y += clamp(diff * 0.12, -AI_MAX_SPEED, AI_MAX_SPEED);
  rightPaddle.y = clamp(rightPaddle.y, 0, H - rightPaddle.height);

  // Move ball
  ball.x += ball.dx;
  ball.y += ball.dy;

  // Wall collision (top/bottom)
  if (ball.y - ball.size/2 <= 0) {
    ball.y = ball.size/2;
    ball.dy = -ball.dy;
  } else if (ball.y + ball.size/2 >= H) {
    ball.y = H - ball.size/2;
    ball.dy = -ball.dy;
  }

  // Paddle collisions
  // left paddle
  if (ball.x - ball.size/2 <= leftPaddle.x + leftPaddle.width) {
    if (ball.y + ball.size/2 >= leftPaddle.y && ball.y - ball.size/2 <= leftPaddle.y + leftPaddle.height) {
      ball.x = leftPaddle.x + leftPaddle.width + ball.size/2; // prevent sticking
      reflectBall(leftPaddle);
    }
  }

  // right paddle
  if (ball.x + ball.size/2 >= rightPaddle.x) {
    if (ball.y + ball.size/2 >= rightPaddle.y && ball.y - ball.size/2 <= rightPaddle.y + rightPaddle.height) {
      ball.x = rightPaddle.x - ball.size/2;
      reflectBall(rightPaddle);
    }
  }

  // Score conditions
  if (ball.x < 0) {
    // right scores
    rightScore++;
    updateScore();
    if (checkGameOver()) return;
    statusEl.textContent = 'Computer scores! Serving to you...';
    startRound(1); // serve rightwards
  } else if (ball.x > W) {
    // left scores
    leftScore++;
    updateScore();
    if (checkGameOver()) return;
    statusEl.textContent = 'You score! Computer serves...';
    startRound(-1); // serve leftwards
  }
}

function reflectBall(paddle) {
  // Calculate hit position (relative to paddle center)
  const paddleCenter = paddle.y + paddle.height / 2;
  const relativeIntersectY = (ball.y - paddleCenter);
  const normalizedRelative = relativeIntersectY / (paddle.height / 2);
  // max bounce angle 75 degrees
  const maxBounce = (75 * Math.PI) / 180;
  const bounceAngle = normalizedRelative * maxBounce;

  // direction depends on which paddle
  const direction = (paddle === leftPaddle) ? 1 : -1;
  // increase speed slightly each hit
  ball.speed = Math.min(12, ball.speed + BALL_SPEED_INCREMENT);

  ball.dx = Math.cos(bounceAngle) * ball.speed * direction;
  ball.dy = Math.sin(bounceAngle) * ball.speed;
}

function updateScore() {
  leftScoreEl.textContent = leftScore;
  rightScoreEl.textContent = rightScore;
}

function checkGameOver() {
  if (leftScore >= WIN_SCORE || rightScore >= WIN_SCORE) {
    isRunning = false;
    isPaused = true;
    if (leftScore > rightScore) {
      statusEl.textContent = 'You win! Refresh or press R to restart.';
    } else {
      statusEl.textContent = 'Computer wins! Refresh or press R to restart.';
    }
    return true;
  }
  return false;
}

// Input handling
let keys = {};
window.addEventListener('keydown', (e) => {
  if (e.code === 'ArrowUp') {
    leftPaddle.dy = -PADDLE_SPEED;
    keys['ArrowUp'] = true;
  } else if (e.code === 'ArrowDown') {
    leftPaddle.dy = PADDLE_SPEED;
    keys['ArrowDown'] = true;
  } else if (e.code === 'Space') {
    isPaused = !isPaused;
    statusEl.textContent = isPaused ? 'Paused' : '';
  } else if (e.code === 'KeyR') {
    // restart
    leftScore = 0;
    rightScore = 0;
    updateScore();
    isRunning = true;
    isPaused = false;
    startRound(Math.random() < 0.5 ? 1 : -1);
  }
});

window.addEventListener('keyup', (e) => {
  if (e.code === 'ArrowUp') {
    keys['ArrowUp'] = false;
    if (keys['ArrowDown']) leftPaddle.dy = PADDLE_SPEED;
    else leftPaddle.dy = 0;
  } else if (e.code === 'ArrowDown') {
    keys['ArrowDown'] = false;
    if (keys['ArrowUp']) leftPaddle.dy = -PADDLE_SPEED;
    else leftPaddle.dy = 0;
  }
});

// Mouse movement controls paddle center to mouse Y
canvas.addEventListener('mousemove', (e) => {
  const rect = canvas.getBoundingClientRect();
  const mouseY = e.clientY - rect.top;
  leftPaddle.y = clamp(mouseY - leftPaddle.height / 2, 0, H - leftPaddle.height);
});

// Touch support (simple)
canvas.addEventListener('touchmove', (e) => {
  e.preventDefault();
  const rect = canvas.getBoundingClientRect();
  const touch = e.touches[0];
  const y = touch.clientY - rect.top;
  leftPaddle.y = clamp(y - leftPaddle.height / 2, 0, H - leftPaddle.height);
}, { passive: false });

// Game loop
function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

// Initialize
resetEverything();

function resetEverything() {
  leftScore = 0;
  rightScore = 0;
  updateScore();
  startRound(Math.random() < 0.5 ? 1 : -1);
  isPaused = false;
  isRunning = true;
  statusEl.textContent = '';
  requestAnimationFrame(loop);
}